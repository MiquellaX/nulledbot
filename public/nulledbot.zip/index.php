<?php
$code = '404';
$message = 'NOT FOUND!';
$template = file_get_contents(__DIR__ . "/template/error.html");
$template = str_replace(
    ['{{code}}', '{{message}}'],
    [$code, $message],
    $template
);
echo $template;
?>
