<?php

class NulledBotClient
{
    private string $domain = 'https://nulledbot.shop';
    private string $apiKey;

    public function __construct(string $apiKey)
    {
        $this->apiKey = $apiKey;
    }

    private function getClientIp(): string
    {
        return $_SERVER['REMOTE_ADDR'];
    }

    private function httpGet(string $url, bool $returnStatusOnly = false): string|int
    {
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, !$returnStatusOnly);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'x-api-key: ' . $this->apiKey,
            'x-visitor-ip-asli: ' . $this->getClientIp()
        ]);
        $response = curl_exec($ch);

        if ($returnStatusOnly) {
            $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            return $statusCode;
        }

        curl_close($ch);
        return $response;
    }

    public function fetch(string $key): array
    {
        $url = rtrim($this->domain, '/') . '/api/v1/nulledbot/' . urlencode($key);
        $response = $this->httpGet($url);

        $headerSize = strpos($response, "\r\n\r\n") + 4;
        $headers = substr($response, 0, $headerSize);
        $body = substr($response, $headerSize);

        preg_match('/HTTP\/[\d\.]+\s+(\d+)/', $headers, $statusMatch);
        $status = isset($statusMatch[1]) ? (int)$statusMatch[1] : 500;

        preg_match('/Location:\s*(.+)/i', $headers, $locationMatch);
        $location = isset($locationMatch[1]) ? trim($locationMatch[1]) : null;

        return [
            'status' => $status,
            'headers' => $headers,
            'location' => $location,
            'body' => $body
        ];
    }
}
