<?php
$nulledbot_api_key = 'PASTEAPIKEYDISINI'; // REQUIRED, PASTE YOUR API KEY HERE
?>
